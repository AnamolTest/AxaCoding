package com.aso.integration.inventory.asnout.utils;

import java.util.HashSet;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import com.aso.integration.inventory.asnout.domain.ASNOut00;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.aso.integration.template.exceptions.KafkaNonRetryableIntegrationException;

@ExtendWith(MockitoExtension.class)
 class MessageValidatorTest {

	@Mock
	private Validator validator;

	@Mock
	ConstraintViolation<ASNOut00> constraintViolation;

	@InjectMocks
	MessageValidator messageValidator;

	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testMessageValidatorForInvalidXml() {
		ASNOut00 asnOut00 = new ASNOut00();
		Set<ConstraintViolation<ASNOut00>> violations = new HashSet<>();
		violations.add(constraintViolation);
		Mockito.when(validator.validate(asnOut00)).thenReturn(violations);
		Assertions.assertThrows(KafkaNonRetryableIntegrationException.class,
				() -> messageValidator.validateInboundRequest(asnOut00, 1));
	}

}