package com.aso.integration.inventory.asnout.consumer;

import com.aso.integration.inventory.asnout.domain.ASNOut00;
import com.aso.integration.inventory.asnout.log.CustomLogger;
import com.aso.integration.inventory.asnout.service.ASNOutEventService;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SpringBootTest
@EmbeddedKafka(topics = {"${application.kafka.deadLetterTopic}",
        "${application.config.consumer.topic}"
        }, partitions = 1)
@TestPropertySource(properties = {
        "spring.kafka.producer.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "spring.kafka.consumer.bootstrap-servers=${spring.embedded.kafka.brokers}",
        "spring.kafka.properties.security.protocol=PLAINTEXT",
        "spring.kafka.consumer.max-poll-records=50",
        "spring.kafka.consumer.fetch-max-wait=4s",
        "spring.kafka.consumer.fetch-min-size=5", "listener.startup=true"})
@DirtiesContext
class ASNOutEventConsumerTest {

	@Autowired
	EmbeddedKafkaBroker embeddedKafkaBroker;

	@Autowired
	KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	KafkaListenerEndpointRegistry endpointRegistry;

	@SpyBean
	ASNOutEventService asnOutEventServiceSpy;

	@SpyBean
	ASNOutEventConsumer asnOutEventConsumerSpy;

	@Value("${spring.kafka.consumer.max-poll-records}")
	private int batchSize;

	@Value("${application.config.consumer.topic}")
	String topic;

	@Value("${application.kafka.deadLetterTopic}")
	private String deadLetterTopic;

	@Value("${application.config.consumer.groupId}")
	String consumerGroupId;

	private Consumer<String, String> consumer;

	MessageListenerContainer container;

	@BeforeEach
	void setUp() {

		container = endpointRegistry.getListenerContainers().stream().filter(
				messageListenerContainer -> Objects.equals(messageListenerContainer.getGroupId(), consumerGroupId))
				.collect(Collectors.toList()).get(0);

		container.start();
		ContainerTestUtils.waitForAssignment(container, embeddedKafkaBroker.getPartitionsPerTopic());

	}

	@AfterEach
	void tearDown() {
		container.stop();
	}

	@Test
	@Order(3)
	@DirtiesContext
	void publishNewEvents() throws ExecutionException, InterruptedException {

		// given
		int noOfMessage = 1;
		// given
		for (int i = 0; i < noOfMessage; i++) {
			kafkaTemplate.send(topic, String.valueOf(i), xmlMessage()).get();
		}

		// when
		CountDownLatch latch = new CountDownLatch(1);
		latch.await(7, TimeUnit.SECONDS);

		// then
		verify(asnOutEventServiceSpy, times(noOfMessage)).processIncomingASNOutMessage(any(ASNOut00.class),
				any(CustomLogger.class));
		
		verify(asnOutEventServiceSpy, times(noOfMessage)).processIncomingASNOutMessage(any(ASNOut00.class),
				any(CustomLogger.class));
	}

	@Test
	@Order(2)
	@DirtiesContext
	void publishNewEvents_FailedValidation_DeadLetter() throws ExecutionException, InterruptedException {

		int noOfMessage = 3;
		// given
		for (int i = 0; i < noOfMessage; i++) {
			kafkaTemplate.send(topic, String.valueOf(i), badXMLMessage()).get();
		}

		// when
		CountDownLatch latch = new CountDownLatch(1);
		latch.await(7, TimeUnit.SECONDS);

		// then
		verify(asnOutEventConsumerSpy, times(noOfMessage)).onMessage(isA(List.class));

		Map<String, Object> configs = new HashMap<>(
				KafkaTestUtils.consumerProps("group-dlq", "true", embeddedKafkaBroker));
		consumer = new DefaultKafkaConsumerFactory<>(configs, new StringDeserializer(), new StringDeserializer())
				.createConsumer();
		embeddedKafkaBroker.consumeFromAnEmbeddedTopic(consumer, deadLetterTopic);

		KafkaTestUtils.getRecords(consumer).forEach(consumerRec -> assertEquals(badXMLMessage(), consumerRec.value()));

	}

	@Test
	@Order(1)
	@DirtiesContext
	void publishNewEvents_DeserializationException_DeadLetter() throws ExecutionException, InterruptedException {

		int noOfMessage = 2;
		// given
		for (int i = 0; i < noOfMessage; i++) {
			kafkaTemplate.send(topic, String.valueOf(i), malformedXMLMessage()).get();
		}

		// when
		CountDownLatch latch = new CountDownLatch(1);
		latch.await(7, TimeUnit.SECONDS);

		// then
		verify(asnOutEventConsumerSpy, times(noOfMessage)).onMessage(isA(List.class));

		Map<String, Object> configs = new HashMap<>(
				KafkaTestUtils.consumerProps("group-dlq", "true", embeddedKafkaBroker));
		consumer = new DefaultKafkaConsumerFactory<>(configs, new StringDeserializer(), new StringDeserializer())
				.createConsumer();
		embeddedKafkaBroker.consumeFromAnEmbeddedTopic(consumer, deadLetterTopic);

		KafkaTestUtils.getRecords(consumer)
				.forEach(consumerRec -> assertEquals(malformedXMLMessage(), consumerRec.value()));

	}

	private String xmlMessage() {

		return "<ASNOut00><trailer_nbr>894530240A</trailer_nbr><seal_nbr>56384</seal_nbr><carrier_code>ACAD</carrier_code><asn_nbr>091497895</asn_nbr><bol_nbr>091497895</bol_nbr><asn_type>C</asn_type><shipment_date>2014-11-09T06:17:44</shipment_date><est_arr_date>2014-11-09T06:17:44</est_arr_date><to_location>005</to_location><from_location>701</from_location><ASNDistro01><distro_nbr>1002514737</distro_nbr><distro_doc_type>A</distro_doc_type><in_store_date>2014-11-09T06:17:44</in_store_date><expedite_flag>N</expedite_flag><ASNCtn002><container_id>894689884091497895</container_id><final_location>894</final_location><ASNItem003><item_id>026390237</item_id><unit_qty>3</unit_qty></ASNItem003></ASNCtn002></ASNDistro01><ASNDistro01><distro_nbr>8002514737</distro_nbr><distro_doc_type>A</distro_doc_type><in_store_date>2014-11-09T06:17:44</in_store_date><expedite_flag>N</expedite_flag><ASNCtn002><container_id>894689884091497895</container_id><final_location>894</final_location><ASNItem003><item_id>026390238</item_id><unit_qty>3</unit_qty></ASNItem003></ASNCtn002></ASNDistro01><container_qty>663</container_qty></ASNOut00>";
	}

	private String badXMLMessage() {

		return "<ASNOut00><trailer_nbr>894530240A</trailer_nbr><seal_nbr>56384</seal_nbr<carrier_code>ACAD</carrier_code><asn_nbr>091497895</asn_nbr><bol_nbr>091497895</bol_nbr><asn_type>C</asn_type><shipment_date>2014-11-09T06:17:44</shipment_date><est_arr_date>2014-11-09T06:17:44</est_arr_date><to_location>005</to_location><ASNDistro01><distro_nbr>1002514737</distro_nbr><distro_doc_type>A</distro_doc_type><in_store_date>2014-11-09T06:17:44</in_store_date><expedite_flag>N</expedite_flag><ASNCtn002><container_id>894689884091497895</container_id><final_location>894</final_location><ASNItem003><item_id>026390237</item_id><unit_qty>3</unit_qty></ASNItem003></ASNCtn002></ASNDistro01><container_qty>663</container_qty></ASNOut00>";
	}

	private String malformedXMLMessage() {

		return "<ASNCtn002><container_id>701042221</container_id><final_location>897</final_location>";
	}
}
