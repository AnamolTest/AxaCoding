package com.aso.integration.inventory.asnout.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import com.aso.integration.inventory.asnout.domain.ASNOut00;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.RecoverableDataAccessException;

import com.aso.integration.template.exceptions.KafkaNonRetryableIntegrationException;

@ExtendWith(MockitoExtension.class)
class MessageConvertorTest {

	private final AutoCloseable closeable;

	@AfterEach
	public void releaseMocks() throws Exception {
		closeable.close();
	}

	public MessageConvertorTest() {
		closeable = MockitoAnnotations.openMocks(this);
	}

	@Test
	void testObjectToXml() {

		final String xmlString = "\n"
				+ "<ASNOut00><trailer_nbr>894530240A</trailer_nbr><seal_nbr>56384</seal_nbr><carrier_code>ACAD</carrier_code><asn_nbr>091497895</asn_nbr><bol_nbr>091497895</bol_nbr><asn_type>C</asn_type><shipment_date>2014-11-09T06:17:44</shipment_date><est_arr_date>2014-11-09T06:17:44</est_arr_date><to_location>005</to_location><from_location>701</from_location><ASNDistro01><distro_nbr>1002514737</distro_nbr><distro_doc_type>A</distro_doc_type><in_store_date>2014-11-09T06:17:44</in_store_date><expedite_flag>N</expedite_flag><ASNCtn002><container_id>894689884091497895</container_id><final_location>894</final_location><ASNItem003><item_id>026390237</item_id><unit_qty>3</unit_qty></ASNItem003></ASNCtn002></ASNDistro01><ASNDistro01><distro_nbr>8002514737</distro_nbr><distro_doc_type>A</distro_doc_type><in_store_date>2014-11-09T06:17:44</in_store_date><expedite_flag>N</expedite_flag><ASNCtn002><container_id>894689884091497895</container_id><final_location>894</final_location><ASNItem003><item_id>026390238</item_id><unit_qty>3</unit_qty></ASNItem003></ASNCtn002></ASNDistro01><container_qty>663</container_qty></ASNOut00>";
		MessageConvertor messageConvertor = new MessageConvertor();
		ConsumerRecord<String, String> record = new ConsumerRecord<>("", 0, 1, "", xmlString);
		ASNOut00 asnOut00 = messageConvertor.convertXMLStringToPOJO(record);
		Assertions.assertEquals("894530240A", asnOut00.getTrailerNbr());
		Assertions.assertNotNull(asnOut00);
	}

	@Test
	void testObjectToInvalidXml() {

		final String invalidXmlString = "\n"
				+ "<ASNCtn002><container_id>701042221</container_id><final_location>897</final_location>";
		MessageConvertor messageConvertor = new MessageConvertor();
		ConsumerRecord<String, String> record = new ConsumerRecord<>("", 0, 1, "", invalidXmlString);

		// when
		Throwable thrown = catchThrowable(() -> messageConvertor.convertXMLStringToPOJO(record));

		// then
		assertThat(thrown).isInstanceOf(KafkaNonRetryableIntegrationException.class)
				.hasMessageContaining("Deserialization Exception:convertXMLStringToPOJO Reason:");

	}	 

}
