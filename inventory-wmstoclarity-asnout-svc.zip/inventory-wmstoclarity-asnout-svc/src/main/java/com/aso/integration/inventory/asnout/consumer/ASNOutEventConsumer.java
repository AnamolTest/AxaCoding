package com.aso.integration.inventory.asnout.consumer;

import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.aso.integration.inventory.asnout.domain.ASNOut00;
import com.aso.integration.inventory.asnout.log.CustomLogger;
import com.aso.integration.inventory.asnout.service.ASNOutEventService;
import com.aso.integration.inventory.asnout.utils.MessageConvertor;
import com.aso.integration.inventory.asnout.utils.MessageValidator;

@Component
public class ASNOutEventConsumer {

    @Autowired
    private ASNOutEventService asnOutEventService;
    @Autowired
    private MessageConvertor messageConvertor;

    @Autowired
    private ApplicationContext applicationContext;
    @Autowired
    private MessageValidator messageValidator;

    /**
     * @param consumerRecords
     */
    @KafkaListener(topics = {"${application.config.consumer.topic}"},
            id = "${application.config.consumer.containerId}",
            groupId = "${application.config.consumer.groupId}",
            autoStartup = "${listener.startup:true}",
            containerFactory = "${application.config.consumer.containerFactory}")
	public void onMessage(final List<ConsumerRecord<String, String>> consumerRecords) {

		for (int index = 0; index < consumerRecords.size(); index++) {

			CustomLogger customLogger = applicationContext.getBean(CustomLogger.class);
			ConsumerRecord<String, String> consumerRecord = consumerRecords.get(index);
			customLogger.logInboundRequest(consumerRecord);
			ASNOut00 asnOut00 = messageConvertor.convertXMLStringToPOJO(consumerRecord);
			messageValidator.validateInboundRequest(asnOut00, index);
			asnOutEventService.processIncomingASNOutMessage(asnOut00, customLogger);

		}

	}
}
