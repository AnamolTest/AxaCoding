package com.aso.integration.inventory.asnout.constants;

public enum ASNOutConstants {

	SKUQUANTITY("SkuQuantity"),

	LOCATIONID("LocationId"),
	
	DATE("Date"),
	
	REFERENCE1("Reference1"),
	
	TYPE("Type"),
	
	SENDING_TO_DLQ_TOPIC("SENDING_TO_DLQ_TOPIC"); 

	private String value;

	ASNOutConstants(String value) {

		this.value = value;
	}

	public String getValue() {

		return this.value;
	}
}
