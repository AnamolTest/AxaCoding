package com.aso.integration.inventory.asnout.utils;

import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.aso.integration.inventory.asnout.domain.ASNOut00;
import com.aso.integration.template.exceptions.KafkaNonRetryableIntegrationException;

@Component
public class MessageValidator {

    @Autowired
    private Validator validator;

    public void validateInboundRequest(ASNOut00 asnOut00, int index) {

        Set<ConstraintViolation<ASNOut00>> violations = validator.validate(asnOut00);
        if (!violations.isEmpty()) {
            String message = violations
                    .stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining(","));

            throw new KafkaNonRetryableIntegrationException("Validation Exception : " + message, index);
        }

    }

}
