package com.aso.integration.inventory.asnout.producer;

import java.util.List;
import java.util.Map;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.json.simple.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import com.aso.integration.inventory.asnout.log.CustomLogger;

@Service
public class ClarityEventProducer {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	public ListenableFuture<SendResult<String, String>> sendClarityEvent(JSONObject asnOut, String topic, CustomLogger customLogger) {

		String value = asnOut.toString();
		String key = null;

		ProducerRecord<String, String> producerRecord = buildProducerRecord(key, value, topic);

		ListenableFuture<SendResult<String, String>> listenableFuture = kafkaTemplate.send(producerRecord);

		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
			@Override
			public void onFailure(Throwable ex) {
				handleFailure(key, value, ex, customLogger);
			}

			@Override
			public void onSuccess(SendResult<String, String> result) {
				customLogger.logOutboundResponse(result);
			}
		});

		return listenableFuture;
	}

	private ProducerRecord<String, String> buildProducerRecord(String key, String value, String topic) {
		List<Header> recordHeaders = List.of(new RecordHeader("CorrelationId", String.valueOf(MDC.get("CorrelationId")).getBytes()));
		return new ProducerRecord<>(topic, 0, key, value, recordHeaders);
	}

	private void handleFailure(String key, String value, Throwable ex, CustomLogger customLogger) {
		StringBuilder messageBuilder = new StringBuilder();
		messageBuilder.append("Exception while publishing data to Kafka for key - ")
		.append(key).append(" and value - ")
		.append(value);
		customLogger.logErrorRequest(String.valueOf(messageBuilder), ex);
	}	


}
