package com.aso.integration.inventory.asnout.service;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.aso.integration.inventory.asnout.constants.ASNOutConstants;
import com.aso.integration.inventory.asnout.domain.ASNOut00;
import com.aso.integration.inventory.asnout.log.CustomLogger;
import com.aso.integration.inventory.asnout.producer.ClarityEventProducer;
 

@Service
public class ASNOutEventService {


	@Value("${application.kafka.deadLetterTopic}")
	private String dlqTopic;
	
	@Value("${application.config.producer.topic}")
	private String producerTopic;

	@Autowired
	private ClarityEventProducer clarityEventProducer;

	 
	
	public void processIncomingASNOutMessage(ASNOut00 asnOut00, CustomLogger customLogger) {
		
		processASNOutEvent(asnOut00, customLogger);
	}

	
	public void processASNOutEvent(ASNOut00 asnOut00, CustomLogger customLogger) {		
		
	JSONObject messageForClarity = new JSONObject();
		messageForClarity.put(ASNOutConstants.SKUQUANTITY.getValue(), getSkuQuantity(asnOut00));
		messageForClarity.put(ASNOutConstants.LOCATIONID.getValue(), asnOut00.getToLocation());
		messageForClarity.put(ASNOutConstants.DATE.getValue(), asnOut00.getShipmentDate());
		messageForClarity.put(ASNOutConstants.REFERENCE1.getValue(), asnOut00.getAsnNbr());
		messageForClarity.put(ASNOutConstants.TYPE.getValue(), "ASN");	
		
		try {
			customLogger.logOutboundRequest(messageForClarity);
			clarityEventProducer.sendClarityEvent(messageForClarity,producerTopic,customLogger);
		} catch (Exception e) {
		customLogger.logErrorRequest(ASNOutConstants.SENDING_TO_DLQ_TOPIC.getValue(),new Exception());
		clarityEventProducer.sendClarityEvent(messageForClarity, dlqTopic, customLogger);
		}
	}

	private JSONObject getSkuQuantity(ASNOut00 item) {
		JSONObject value = new JSONObject();
		
		item.getASNDistro01().stream().forEach(distro -> {
			distro.getASNCtn002().stream().forEach(ctn -> {
						ctn.getASNItem003().stream()
						.forEach(skuitem->
						{
							value.put(skuitem.getItemId(), skuitem.getUnitQty());
						});					
						
					});
				});		

		return value;
	}
}