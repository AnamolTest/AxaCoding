package com.aso.integration.inventory.asnout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.aso.integration.inventory.asnout.consumer","com.aso.integration.inventory.asnout.constants","com.aso.integration.inventory.asnout.domain","com.aso.integration.inventory.asnout.log","com.aso.integration.inventory.asnout.producer","com.aso.integration.inventory.asnout.service","com.aso.integration.inventory.asnout.utils"})
public class InventoryWMStoClarityASNOutSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryWMStoClarityASNOutSvcApplication.class, args);
	}

}
