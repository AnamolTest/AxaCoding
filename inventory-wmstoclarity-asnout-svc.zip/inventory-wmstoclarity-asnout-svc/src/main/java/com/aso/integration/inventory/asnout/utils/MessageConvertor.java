package com.aso.integration.inventory.asnout.utils;

import java.io.StringReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import com.aso.integration.inventory.asnout.domain.ASNOut00;
import com.aso.integration.template.exceptions.KafkaNonRetryableIntegrationException;

@Service
public class MessageConvertor {

	public ASNOut00 convertXMLStringToPOJO(ConsumerRecord<String, String> consumerRecord) {
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(ASNOut00.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			return (ASNOut00) jaxbUnmarshaller.unmarshal(new StringReader(consumerRecord.value()));
		} catch (JAXBException e) {
			throw new KafkaNonRetryableIntegrationException(
					"Deserialization Exception:convertXMLStringToPOJO Reason: " + e.getMessage(), consumerRecord);
		}
	}


}
