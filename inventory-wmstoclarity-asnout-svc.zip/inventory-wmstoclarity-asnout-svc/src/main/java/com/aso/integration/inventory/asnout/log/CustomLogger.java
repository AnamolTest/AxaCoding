package com.aso.integration.inventory.asnout.log;

import com.aso.integration.inventory.asnout.domain.ASNOut00.ASNDistro01;
import com.aso.integration.logger.annotations.LogError;
import com.aso.integration.logger.annotations.LogInboundRequest;
import com.aso.integration.logger.annotations.LogOutboundRequest;
import com.aso.integration.logger.annotations.LogOutboundResponse;
import com.aso.integration.template.util.Constants;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.json.simple.JSONObject;
import org.slf4j.MDC;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.UUID;

@Component
@Scope("prototype")
public class CustomLogger {

    private String correlationId = UUID.randomUUID().toString();

    public String getCorrelationId() {
        return correlationId;
    }


    public void setCorrelationId(final String correlationId) {

        this.correlationId = correlationId;
    }

    @LogInboundRequest
    public ConsumerRecord<String, String> logInboundRequest(
            final ConsumerRecord<String, String> consumerRecord) {
        putCorrelationId(consumerRecord);
        return consumerRecord;
    }

    @LogError
    public Throwable logErrorRequest(String message, Throwable ex) {
        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        MDC.put("ErrorInfo", message);
        return ex;
    }

    @LogOutboundRequest
    public JSONObject logOutboundRequest(JSONObject rtd00) {

        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        return rtd00;
    }

    @LogOutboundRequest
    public JSONObject logOutboundRequest(JSONObject rtd00, String message) {

        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        MDC.put("MoreInfo", message);
        return rtd00;
    }
    
    
    @LogOutboundRequest
    public ASNDistro01 logOutboundRequest(ASNDistro01 distro, String message) {

        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        MDC.put("MoreInfo", message);
        return distro;
    }

    @LogOutboundResponse
    public ResponseEntity<String> logOutboundResponse(ResponseEntity<String> response) {
        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        return response;
    }

    @LogOutboundResponse
    public SendResult<String, String> logOutboundResponse(SendResult<String, String> result) {
        MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        return result;
    }

    private void putCorrelationId(
            final ConsumerRecord<String, String> consumerRecord) {

        Header correlationHeader = Arrays.stream(consumerRecord.headers()
                        .toArray()).filter(header -> header.key()
                        .equals(Constants.CORRELATION_ID.getValue()))
                .findAny()
                .orElse(null);

        if (correlationHeader != null) {

            consumerRecord.headers().forEach(header -> {
                if (header.key() != null && header.key()
                        .equals(Constants.CORRELATION_ID.getValue())) {
                    MDC.put(Constants.CORRELATION_ID.getValue(),
                            new String(header.value()));
                    this.setCorrelationId(new String(header.value()));
                }
            });
        } else {
            MDC.put(Constants.CORRELATION_ID.getValue(), getCorrelationId());
        }

    }
}
