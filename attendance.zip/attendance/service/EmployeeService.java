package com.sapient.mgmt.attendance.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.sapient.mgmt.attendance.dao.Employee;

@Service
@Transactional
public interface EmployeeService {
	boolean getByEmail(String email);
	void addEmployee(Employee employee) ;
	Employee findByEmail(String email);
	void deleteEmployee(long eid);
	void updateEmployee(long eid, Employee employee);	
    Employee getById(long eid);
		
}
