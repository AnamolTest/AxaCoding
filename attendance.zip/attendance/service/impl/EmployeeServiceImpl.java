package com.sapient.mgmt.attendance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sapient.mgmt.attendance.dao.Employee;
import com.sapient.mgmt.attendance.repo.EmployeeRepo;
import com.sapient.mgmt.attendance.service.EmployeeService;
import com.sapient.mgmt.attendance.service.exception.ResourceNotFoundException;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepo employeeRepo;

	@Override
	public boolean getByEmail(String email) {
		if(employeeRepo.existsByEmail(email)) {
			return true;
		}
		
		return false;
	}

	@Override
	public void addEmployee(Employee employee) {
		employeeRepo.save(employee);
		
	}

	@Override
	public Employee findByEmail(String email) {
		return employeeRepo.findByEmail(email).orElseThrow(() -> new ResourceNotFoundException(
				"Employee", "email", email));
	
	}
	
	@Override
	public Employee getById(long eid) {
		return employeeRepo.findById(eid)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Employee", "employeeId", eid));
	}
	

	@Override
	public void deleteEmployee(long eid) {
		employeeRepo.deleteById(eid);
		
	}

	@Override
	public void updateEmployee(long eid, Employee employee) {
		Employee edit = employeeRepo.findById(eid).get();
		edit.setFullName(employee.getFullName());
		edit.setEmail(employee.getEmail());
		employeeRepo.save(edit);
		
	}

}
