package com.sapient.mgmt.attendance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sapient.mgmt.attendance.dao.Attendance;
import com.sapient.mgmt.attendance.dao.Employee;
import com.sapient.mgmt.attendance.repo.AttendanceRepo;
import com.sapient.mgmt.attendance.service.AttendanceService;
import com.sapient.mgmt.attendance.service.exception.ResourceNotFoundException;

@Service
public class AttendanceServiceImpl implements AttendanceService{
	
	@Autowired
	AttendanceRepo attendanceRepo;

	@Override
	public List<Attendance> listAllAttendanceFromEmployee(Employee emp) {
		
		return attendanceRepo.listAttendancesFromEmployee(emp);
	}

	@Override
	public List<Attendance> listAllAttendanceFromUserBetweenDate(Employee user, String startDate, String endDate) {
		return attendanceRepo.listAllAttendanceFromEmployeeBetweenDate(user, startDate, endDate);
	}

	@Override
	public Attendance getById(long attendanceId) {
		return attendanceRepo.findById(attendanceId).orElseThrow(() -> new ResourceNotFoundException(
				"Attendance", "attendanceId", attendanceId));
	}

}
