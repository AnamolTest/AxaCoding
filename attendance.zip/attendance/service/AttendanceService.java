package com.sapient.mgmt.attendance.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sapient.mgmt.attendance.dao.Attendance;
import com.sapient.mgmt.attendance.dao.Employee;

@Service
public interface AttendanceService {
	List<Attendance> listAllAttendanceFromEmployee(Employee emp);
	List<Attendance> listAllAttendanceFromUserBetweenDate(Employee user, String startDate, String endDate);
	Attendance getById(long attendanceId);

}
