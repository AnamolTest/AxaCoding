package com.sapient.mgmt.attendance.dao;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;




@Entity
@Table
public class Attendance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long attendanceId;
	@Temporal(TemporalType.TIMESTAMP)
	private Date checkIn;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date checkOut;

	@Column(nullable = true)
	private long    timeWorkInMins;
	@Column(nullable = true)
	private boolean hasCheckIn = false;
	@Column(nullable = true)
	private boolean hasCheckOut = false;
	@Column(nullable = true)
	private long totalHours = -1;

	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "empId", referencedColumnName = "empId")
	private Employee employee;
	
	public long getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(long attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}
	public long getTimeWorkInMins() {
		return timeWorkInMins;
	}

	public void setTimeWorkInMins(long timeWorkInMins) {
		this.timeWorkInMins = timeWorkInMins;
	}

	public boolean isHasCheckIn() {
		return hasCheckIn;
	}

	public void setHasCheckIn(boolean hasCheckIn) {
		this.hasCheckIn = hasCheckIn;
	}

	public boolean isHasCheckOut() {
		return hasCheckOut;
	}

	public void setHasCheckOut(boolean hasCheckOut) {
		this.hasCheckOut = hasCheckOut;
	}

	public long getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(long totalHours) {
		this.totalHours = totalHours;
	}

	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}




}
