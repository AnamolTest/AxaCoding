package com.sapient.mgmt.attendance.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sapient.mgmt.attendance.dao.Attendance;
import com.sapient.mgmt.attendance.dao.Employee;

@Repository
public interface AttendanceRepo extends JpaRepository<Attendance, Long>{

	@Query(value = "SELECT a FROM Attendance a WHERE a.employee IN :empId"
			+ " ORDER BY a.attendanceId DESC")
	public List<Attendance> listAttendancesFromEmployee(@Param("empId") Employee employee);
	
	@Query(value = "SELECT a FROM Attendance a WHERE a.employee IN :empId"
			+ " AND a.checkIn BETWEEN :startDate AND :endDate"
			+ " ORDER BY a.attendanceId DESC")
	public List<Attendance> listAllAttendanceFromEmployeeBetweenDate(@Param("empId") Employee empId,
			@Param("startDate") String startDate, @Param("endDate") String endDate);

}
