package com.sapient.mgmt.attendance.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.sapient.mgmt.attendance.dao.Attendance;
import com.sapient.mgmt.attendance.dao.Employee;
import com.sapient.mgmt.attendance.repo.AttendanceRepo;
import com.sapient.mgmt.attendance.repo.EmployeeRepo;
import com.sapient.mgmt.attendance.service.AttendanceService;
import com.sapient.mgmt.attendance.service.exception.ResourceNotFoundException;

@RestController
@RequestMapping(value="/sapient/attendance")
public class AttendanceController {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired 
	AttendanceRepo attendanceRepo;
	
	@Autowired
	private AttendanceService attendanceService;

	private DateFormat tsf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	private DateFormat tf = new SimpleDateFormat("HH:mm");
	
	@PostMapping(value = "/check/in")
	public ResponseEntity<?> CheckInAttend(@RequestBody Employee employee) throws Exception {
		
		Employee employee1 =  employeeRepo.findByEmail((employee.getEmail()))
				.orElseThrow(() -> new ResourceNotFoundException("FullName", "fullName", employee.getEmail()));
		
		List<Attendance> list = attendanceService.listAllAttendanceFromEmployee(employee1);
		
	
		for(Attendance ls : list) {	
		if (ls != null && ls.getCheckIn().getTime() == ls.getCheckOut().getTime() 
				&& ls.isHasCheckIn() == true && ls.isHasCheckOut() == false) {
			System.out.println(ls.getAttendanceId());
			
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
					"This user already chek in! Please check out first to do another check in.");
		}
	}
		
	UpdateAttendanceDetails(employee1);
		
	return ResponseEntity.status(HttpStatus.OK).body("ChekIn successfully execute.");
}
	
	@PostMapping(value = "/check/out")
	public ResponseEntity<?> CheckOutAttend(@RequestBody Employee employee) {
		
		Employee user =  employeeRepo.findByEmail((employee.getEmail())) 
    	        .orElseThrow(() -> new ResourceNotFoundException("Users", "userId", employee.getEmpId()));
		
		List<Attendance> ls = attendanceService.listAllAttendanceFromEmployee(user);
		
		for (Attendance at : ls) {
			
			if (at.getCheckIn().getTime() == at.getCheckOut().getTime() 
					&& at.isHasCheckIn() == true && at.isHasCheckOut() == false) {
				System.out.println(at.getAttendanceId());
				
				java.util.Date timeStamp = new java.util.Date();
				
				Attendance attendance = attendanceService.getById(at.getAttendanceId());
				
				attendance.setCheckOut(timeStamp);
				attendance.setHasCheckOut(true);
				
				long diffInMillies = Math.abs(timeStamp.getTime() - attendance.getCheckIn().getTime());
				long diffInMins = TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);				
				attendance.setTimeWorkInMins(diffInMins);			
				attendanceRepo.save(attendance);
				
				break;
				
			} else {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
						"This user has not check in!. Please do check in first.");
			}
			
		}
		System.out.println("outside for loop");
		
		return ResponseEntity.status(HttpStatus.OK).body("ChekOut successfully execute.");
	}
	
	
	

	private void updateTimeInAttendanceTable(Attendance ls, Employee employee1) {
		java.util.Date timestamp = new java.util.Date();
		Attendance attendance = new Attendance();
		attendance.setCheckIn(timestamp);
		attendance.setCheckOut(ls.getCheckOut());
		attendance.setHasCheckIn(true);
		attendance.setEmployee(employee1);
		
		long checkHoursMillies = TimeUnit.MILLISECONDS.convert(dateToCalendar(ls.getCheckIn()).get(Calendar.HOUR_OF_DAY), TimeUnit.HOURS);
		long checkMinsMillies = TimeUnit.MILLISECONDS.convert(dateToCalendar(ls.getCheckIn()).get(Calendar.MINUTE), TimeUnit.MINUTES);
		long checkMillies = checkHoursMillies + checkMinsMillies;
		
		long checkOutHoursMillies = TimeUnit.MILLISECONDS.convert(dateToCalendar(ls.getCheckOut()).get(Calendar.HOUR_OF_DAY), TimeUnit.HOURS);
		long checkOutMinsMillies = TimeUnit.MILLISECONDS.convert(dateToCalendar(ls.getCheckOut()).get(Calendar.MINUTE), TimeUnit.MINUTES);
		long checOutkMillies = checkOutHoursMillies + checkOutMinsMillies;
		
		attendance.setTotalHours(checOutkMillies - checkMillies);
     	attendanceRepo.save(attendance);
		
	}

	private void UpdateAttendanceDetails(Employee employee1) {
		java.util.Date timestamp = new java.util.Date();
		Attendance attendance = new Attendance();
		attendance.setCheckIn(timestamp);
		attendance.setCheckOut(timestamp);
		attendance.setHasCheckIn(true);
		attendance.setEmployee(employee1);		
     	attendanceRepo.save(attendance);
	}
	
	public static Calendar dateToCalendar(java.util.Date date){ 
		  Calendar cal = Calendar.getInstance();
		  cal.setTime(date);
		  return cal;
		}
	
}

