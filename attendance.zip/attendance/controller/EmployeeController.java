package com.sapient.mgmt.attendance.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.sapient.mgmt.attendance.dao.Employee;
import com.sapient.mgmt.attendance.service.EmployeeService;

@RestController
@RequestMapping(value = "/sapient/emp")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping()
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee){
		
		if(employeeService.getByEmail(employee.getEmail())==true) {
			throw new ResponseStatusException(HttpStatus.CONFLICT,"This User already register as an Employee!");
		}

		employeeService.addEmployee(employee);
	
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body("Employee has successfully registered!");
	}
	
	
	@GetMapping(value = "/{eid}")
	public ResponseEntity<?> getEmployee(@PathVariable Long eid) {
		Employee employee = employeeService.getById(eid);		
		return ResponseEntity.ok(employee);		
	}
	
	
	@PutMapping(value = "edit/{eid}")
	public ResponseEntity<?> editEmployee(@PathVariable Long eid, @RequestBody Employee employee) {
		employeeService.updateEmployee(eid, employee);
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Employee successfully updated!");
	}
	
	@DeleteMapping(value = "delete/{eid}")
	public ResponseEntity<?> deleteEmployee(@PathVariable Long eid){
		employeeService.deleteEmployee(eid);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Employee successfully deleted!");
	}
	
}
 