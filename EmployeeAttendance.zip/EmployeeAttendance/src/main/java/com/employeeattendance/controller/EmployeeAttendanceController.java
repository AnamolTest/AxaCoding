package com.employeeattendance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.employeeattendance.entity.Attendance;
import com.employeeattendance.entity.AttendanceId;
import com.employeeattendance.entity.Employee;
import com.employeeattendance.entity.Swipe;
import com.employeeattendance.service.EmployeeAttendanceService;
import com.employeeattendance.service.KafKaProducer;

@RestController
@RequestMapping("/Employee")
public class EmployeeAttendanceController {
	
	@Autowired
	EmployeeAttendanceService employeeAttendanceService;
	
	@Autowired
	KafKaProducer kafKaProducer;

	@RequestMapping("/createUpdateEmployee")
	public @ResponseBody Long createEmployee(@RequestBody Employee employee) {
		
		Long emInteger=employeeAttendanceService.createEmployee(employee);
		return emInteger;
	}
	
	@GetMapping("/getAllEmployees")
	public @ResponseBody List<Employee> getAllEmployee() {
		
		List<Employee> emplList=employeeAttendanceService.getAllEmployee();
		return emplList;
	}
	
	@GetMapping("/getEmployee/{id}")
	public @ResponseBody Employee getEmployeeById(@PathVariable("id") Long empId) {
		
		Employee empDetails=employeeAttendanceService.getEmployeeById(empId);
		return empDetails;
	}
	
	@RequestMapping("/checkinCheckoutEmployee")
	public @ResponseBody Swipe checkinCheckoutEmployee(@RequestBody Swipe swipe) {
		
		System.out.println(swipe.getSwipeId().getId());
		System.out.println(swipe.getSwipeId().getSwipeDate());
		System.out.println(swipe.getSwipeId().getSwipeTime());
		System.out.println(swipe.getSwipeType());
		
		Swipe swipe2=employeeAttendanceService.checkinCheckoutEmployee(swipe);
		return swipe2;
	}
	
	@RequestMapping("/getTotalHoursForDate")
	public @ResponseBody Long getTotalHoursForDate(@RequestParam Long id,@RequestParam String swipeDate) {
		
		System.out.println(id);	
		System.out.println(swipeDate);
		
		Long totalHours=employeeAttendanceService.getTotalHoursForDate(id,swipeDate);
		Attendance attendance=new Attendance();
		AttendanceId attendanceId=new AttendanceId();
		attendanceId.setId(id);
		attendanceId.setSwipeDate(swipeDate);
		attendance.setAttendanceId(attendanceId);
		attendance.setTotalHours(totalHours);
		
		kafKaProducer.sendMessage(attendance);
		return totalHours;
	}
	
	@RequestMapping("/getEmployeePresenceDetails")
	public @ResponseBody Attendance getEmployeePresenceDetails(@RequestParam Long id,@RequestParam String swipeDate) {
		
		System.out.println(id);	
		System.out.println(swipeDate);
		
		return employeeAttendanceService.getEmployeePresenceDetails(id,swipeDate);
	}
}

