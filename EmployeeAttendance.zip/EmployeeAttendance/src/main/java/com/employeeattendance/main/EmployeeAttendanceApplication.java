package com.employeeattendance.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.employeeattendance.controller",
		"com.employeeattendance.service",
		"com.employeeattendance.serviceImpl","com.employeeattendance.repository",
		"com.employeeattendance.repositoryImpl","com.employeeattendance.entity",
		"com.employeeattendance.custom"} )
@EnableJpaRepositories("com.employeeattendance.repository")
@EnableJpaAuditing
@EntityScan("com.employeeattendance.entity")
public class EmployeeAttendanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAttendanceApplication.class, args);
	}

}
