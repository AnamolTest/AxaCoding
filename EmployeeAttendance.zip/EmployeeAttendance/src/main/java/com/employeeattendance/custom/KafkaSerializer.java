package com.employeeattendance.custom;

import java.util.Map;

import org.apache.kafka.common.serialization.Serializer;

import com.employeeattendance.entity.Attendance;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class KafkaSerializer implements Serializer<Attendance> {

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
    }

    @Override
    public byte[] serialize(String topic, Attendance data) {
        try {
            return objectMapper.writeValueAsBytes(data);
        } catch (JsonProcessingException e) {
           System.out.println("Unable to serialize object {} "+ data+" Exception"+ e);
            return null;
        }
    }

    @Override
    public void close() {
    }
}