package com.employeeattendance.custom;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;

import com.employeeattendance.entity.Attendance;
import com.fasterxml.jackson.databind.ObjectMapper;

public class KafkaDeserializer implements Deserializer<Attendance> {

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
    }

    @Override
    public Attendance deserialize(String topic, byte[] data) {
        try {
            return objectMapper.readValue(new String(data, "UTF-8"), Attendance.class);
        } catch (Exception e) {
            System.out.println("Unable to deserialize message {}"+ data+ " Exception "+ e);
            return null;
        }
    }

    @Override
    public void close() {
    }
}