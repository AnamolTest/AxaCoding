package com.employeeattendance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.employeeattendance.entity.Attendance;
import com.employeeattendance.entity.Swipe;

@Repository
public interface SwipeRepository extends JpaRepository<Swipe, Long>{

	@Query(value = "SELECT * FROM swipe where id = ?1 AND swipe_date = ?2 AND swipe_type= ?3", nativeQuery = true)
	List<Swipe> getSwipeDataIdDateandType(Long id, String swipeDate,String swipeType);

	

}
