package com.employeeattendance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.employeeattendance.entity.Attendance;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long>{

	@Query(value = "SELECT * FROM attendance where id = ?1 AND swipe_date = ?2", nativeQuery = true)
	Attendance getPresenceDatabyIdandDate(Long id, String swipeDate);

}
