package com.employeeattendance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.employeeattendance.entity.Attendance;
import com.employeeattendance.repository.AttendanceRepository;

@Service
public class KafKaConsumer 
{
	
	@Autowired
	AttendanceRepository attendanceRepository;
	
    @KafkaListener(topics = "employeeAttendance", 
            groupId = "my_group")
    public void consume(Attendance message) 
    {
        if(message.getTotalHours() < 4) {
        	message.setPresence("A");
        }else if (message.getTotalHours() > 4 && message.getTotalHours()< 8) {
        	message.setPresence("HD");
        } else if (message.getTotalHours() > 8) {
        	message.setPresence("P");
        } 
        
        System.out.println("Received message"+message.getAttendanceId().getId());
        System.out.println("Received message"+message.getAttendanceId().getSwipeDate());
        System.out.println("Received message"+message.getTotalHours());
        System.out.println("Received message"+message.getPresence());
        
        attendanceRepository.saveAndFlush(message);
        
    }
}