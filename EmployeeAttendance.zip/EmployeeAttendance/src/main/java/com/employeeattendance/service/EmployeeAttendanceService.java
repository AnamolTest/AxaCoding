package com.employeeattendance.service;

import java.util.List;

import com.employeeattendance.entity.Attendance;
import com.employeeattendance.entity.Employee;
import com.employeeattendance.entity.Swipe;

public interface EmployeeAttendanceService {
	
	public Long createEmployee(Employee e);
	
	public List<Employee> getAllEmployee();

	public Employee getEmployeeById(Long empId);

	public Swipe checkinCheckoutEmployee(Swipe swipe);

	public Long getTotalHoursForDate(Long id, String swipeDate);

	public Attendance getEmployeePresenceDetails(Long id, String swipeDate);
 
}
