package com.employeeattendance.serviceImpl;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeattendance.entity.Attendance;
import com.employeeattendance.entity.Employee;
import com.employeeattendance.entity.Swipe;
import com.employeeattendance.repository.AttendanceRepository;
import com.employeeattendance.repository.EmployeeRepository;
import com.employeeattendance.repository.SwipeRepository;
import com.employeeattendance.service.EmployeeAttendanceService;
 
@Service
public class EmployeeAttendanceServiceImpl implements EmployeeAttendanceService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	SwipeRepository swipeRepository;
	
	@Autowired
	AttendanceRepository attendanceRepository;
	
	public Long createEmployee(Employee e) {
		
	Employee employee=	employeeRepository.saveAndFlush(e);
	
	return employee.getId();	
	
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		List<Employee> employees=employeeRepository.findAll();
		return employees;
	}

	@Override
	public Employee getEmployeeById(Long empId) {
		Employee employee = employeeRepository.getById(empId);
		return employee;
	}

	@Override
	public Swipe checkinCheckoutEmployee(Swipe swipe) {
		
		Swipe swipe2=	swipeRepository.saveAndFlush(swipe);
		
		return swipe2;
	}

	/*
	 * Minutes will not considered to calculate hours
	 */
	@Override
	public Long getTotalHoursForDate(Long id, String swipeDate) {
		
		
		List<Swipe> swipeInList = swipeRepository.getSwipeDataIdDateandType(id,swipeDate,"IN");
		
		List<Swipe> swipeOutList = swipeRepository.getSwipeDataIdDateandType(id,swipeDate,"OUT");
		
		List<LocalTime> t=new ArrayList<>();
		
		swipeInList.stream().forEach(s -> {
			t.add(LocalTime.parse(s.getSwipeId().getSwipeTime()));
		});
				
		
		Collections.sort(t);
		
		LocalTime firstInOfDay = t.get(0);
		
		System.out.println("First In Of Day "+t.get(0));

		List<LocalTime> t1=new ArrayList<>();
		
		swipeOutList.stream().forEach(s -> {
			t1.add(LocalTime.parse(s.getSwipeId().getSwipeTime()));
		});
		
		Collections.sort(t1);
		
		LocalTime lastOutOfDay = t1.get(t1.size()-1);
				
		System.out.println("Last Out Of Day "+t1.get(t1.size()-1));
		
		return firstInOfDay.until(lastOutOfDay, ChronoUnit.HOURS);
	}

	@Override
	public Attendance getEmployeePresenceDetails(Long id, String swipeDate) {
		
		Attendance attendance = attendanceRepository.getPresenceDatabyIdandDate(id,swipeDate);
		return attendance;
	}
 
}

