package com.employeeattendance.entity;

import java.io.Serializable;

import jakarta.persistence.*;

@Entity
@Table(name = "Attendance")
public class Attendance implements Serializable{
    
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private AttendanceId attendanceId;
	
	@Column(name = "totalHours", nullable = false)
    private Long totalHours;
	
	@Column(name = "presence", nullable = false)
    private String presence;

	public AttendanceId getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(AttendanceId attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Long getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(Long totalHours2) {
		this.totalHours = totalHours2;
	}

	public String getPresence() {
		return presence;
	}

	public void setPresence(String presence) {
		this.presence = presence;
	}
}