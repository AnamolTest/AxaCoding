package com.employeeattendance.entity;

import java.io.Serializable;

import jakarta.persistence.*;

@Embeddable
public class SwipeId implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "Id", nullable = false)
    private Long id;
	
	@Column(name = "swipeDate", nullable = false)
    private String swipeDate;
	
	@Column(name = "swipeTime", nullable = false)
    private String swipeTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSwipeDate() {
		return swipeDate;
	}

	public void setSwipeDate(String swipeDate) {
		this.swipeDate = swipeDate;
	}

	public String getSwipeTime() {
		return swipeTime;
	}

	public void setSwipeTime(String swipeTime) {
		this.swipeTime = swipeTime;
	}
    
}