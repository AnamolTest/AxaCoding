package com.employeeattendance.entity;

import java.io.Serializable;

import jakarta.persistence.*;

@Entity
@Table(name = "Swipe")
public class Swipe implements Serializable{
    
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private SwipeId swipeId;
	
	@Column(name = "swipeType", nullable = false)
    private String swipeType;

	public SwipeId getSwipeId() {
		return swipeId;
	}

	public void setSwipeId(SwipeId swipeId) {
		this.swipeId = swipeId;
	}

	public String getSwipeType() {
		return swipeType;
	}

	public void setSwipeType(String swipeType) {
		this.swipeType = swipeType;
	}
	
}